# LPT
projeto para para substituir o trilhas literárias de Hortolândia

## Violações heuristicas encontradas pela analise de usabilidade
<<<<<<< HEAD
| SOLUCIONA | 	TELA 	| 	PROBLEMA IDENTIFIFCADO 	| HEURISTICA VIOLADA |
| - [x]		|	MENU	|	O menu está com uma cor que não permite	um destaque podendo	confundir o usuário	|Consistência e padrão|			
| []		| MAPA		| Não possui informações de uso do sistema é preciso colocar instruções|Help e documentação |			  
| []	| Inicial/Tecnologia utilizadas/ QR Code como usar|As informações podem confundir os usuários de como utilizar o sistema de QR Code |Help e documentação/ Compatibilidade do sistema com o mundo real|
| [] |Mapa|O usuário não tem mecanismo para auxiliar na busca em relação ao endereço |Flexibilidade e eficiência de uso|
| [X] |Portal/Sistema|O sistema não possui help|Help e documentação|
|[x]|Links para sites livros/ Links extras|O usuário não pode clicar no texto para ser direcionado ao site, é necessário o clique na imagem.|Consistência e padrões/ Reconhecimento ao invés de relembrança|
|[x]|Cartaz|Em telas menores se torna mais difícil ler o cartaz, pois ele é encolhido somente horizontalmente |Consistência e padrões|
|[x]|Menu Superior|Ao passar o mouse em cima do botão, poderia mostrar o botão como inteiro e não só as letras quando selecionado, e estética do menu com um plano cinza|Estética e design minimalista/Consistência e padrões|
|[x]|Tela Inicial|O fundo superior com o título poderia possuir uma imagem relacionado ao tema do site|Estética e design minimalista|
|[]|Mapa|Ao clicar no ponteiro deveria mostrar a imagem do local com os pontos que os cartazes se encontram|Estética e design minimalista|
|[X]|Mapa|Indicador ou ponteiro que mostra as localizações são comuns|Consistência e padrões|
|[x]|Sobre o projeto/ QR Code como usar/ Sites de livros/ Links externos|Fundo do título só com plano cinza|Estética e design minimalista
|[x]|Sites de livros |Ao clicar na imagem abre o link da página selecionada, mas sem a necessidade de ter algo escrito embaixo das imagens|Consistência e padrões|
|[X]|Sistema|Formatação dos textos, imagens e outros conteúdos|Estética e design minimalista|
=======
|RESOLVIDO|TELA|PROBLEMA IDENTIFIFCADO|HEURISTICA VIOLADA|
| ------------- |:-------------:| -----:|----:|
|[x] |MENU|	O menu está com uma cor que não permite	um destaque podendo	confundir o usuário	|Consistência e padrão|			
|[ ] |MAPA		| Não possui informações de uso do sistema é preciso colocar instruções|Help e documentação |			  
| [ ] |Inicial/Tecnologia utilizadas/ QR Code como usar|As informações podem confundir os usuários de como utilizar o sistema de QR Code |Help e documentação/ Compatibilidade do sistema com o mundo real|
| [ ] |Mapa|O usuário não tem mecanismo para auxiliar na busca em relação ao endereço |Flexibilidade e eficiência de uso|
| [ ] |Portal/Sistema|O sistema não possui help|Help e documentação|
|[x] |Links para sites livros/ Links extras|O usuário não pode clicar no texto para ser direcionado ao site, é necessário o clique na imagem.|Consistência e padrões/ Reconhecimento ao invés de relembrança|
|[x] |Cartaz|Em telas menores se torna mais difícil ler o cartaz, pois ele é encolhido somente horizontalmente |Consistência e padrões|
|[x] |Menu Superior|Ao passar o mouse em cima do botão, poderia mostrar o botão como inteiro e não só as letras quando selecionado, e estética do menu com um plano cinza|Estética e design minimalista/Consistência e padrões|
|[x] |Tela Inicial|O fundo superior com o título poderia possuir uma imagem relacionado ao tema do site|Estética e design minimalista|
|[ ] |Mapa|Ao clicar no ponteiro deveria mostrar a imagem do local com os pontos que os cartazes se encontram|Estética e design minimalista|
|[ ] |Mapa|Indicador ou ponteiro que mostra as localizações são comuns|Consistência e padrões|
|[x] |Sobre o projeto/ QR Code como usar/ Sites de livros/ Links externos|Fundo do título só com plano cinza|Estética e design minimalista
|[x] |Sites de livros |Ao clicar na imagem abre o link da página selecionada, mas sem a necessidade de ter algo escrito embaixo das imagens|Consistência e padrões|
|[x] |Sistema|Formatação dos textos, imagens e outros conteúdos|Estética e design minimalista|
>>>>>>> c6f8b672b79f38de207191837c41b2e8bc7fa381
